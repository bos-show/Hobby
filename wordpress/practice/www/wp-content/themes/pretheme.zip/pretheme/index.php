<?php get_header(); ?>
<p>hello</p>
<?php get_footer(); ?>
