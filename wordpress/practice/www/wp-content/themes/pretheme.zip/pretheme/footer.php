</div>
<!-- footer -->
<footer>
  <h1>
    One × One Hair
  </h1>
  <p>
    富山One×OneHAIR(ワンバイワンヘア)
  </p>
  <p>
    美容室美容院
  </p>
  <p>
    TEL:076-461-3122
  </p>
  <p>
    [営業時間] 平日 am9:00~pm20:00
  </p>
  <p>
    (カット最終受付19:00)
  </p>
  <p>土・日・祝日 am9:00~pm19:00
  </p>
  <p>
    (カット最終受付18:00)
  </p>
  <p>
    [定休日] 月曜日
  </p>
  <div class="icon">
    <a href="https://www.instagram.com/onebyone_kenta/">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/footer/insta.png">
  </a>
  <a href="https://www.facebook.com/pages/category/Beauty--Cosmetic---Personal-Care/OneOne-hair-457104818111638/">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/footer/facebook.png">
  </a>
  </div>
  <img class="fbg" src="<?php echo get_template_directory_uri(); ?>/assets/footer/footer-bg.png">
</footer>
